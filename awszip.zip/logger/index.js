const log = require('tracer').colorConsole({level: process.env.LOG_LEVEL});
module.exports = log;
